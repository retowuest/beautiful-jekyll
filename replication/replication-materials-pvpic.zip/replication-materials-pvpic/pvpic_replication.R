######################################################################################
#                    Parliamentary Voting Procedures in Comparison                   #
#                                                                                    #
#                     West European Politics Vol 38 Issue 5, 2015                    #
#     Special Issue: Explaining Legislative Organization in European Democracies     #
#                                                                                    #
#                                      02/03/2016                                    #
#                                                                                    #
#                        Simon Hug, Simone Wegmann, Reto Wüest                       #
######################################################################################


# Install or load packages

library(install.load)  # if necessary: install.packages("install.load")

install_load("arm", "dplyr")


# Set working directory

your.path <- "..."
setwd(your.path)


# Load parliamentary voting data

rm(list = ls())
load("sop_europe.RData")


# For variable sop.final, add information on Greece and Iceland
# Source Greece: http://www.hellenicparliament.gr/en/Vouli-ton-Ellinon/Kanonismos-tis-Voulis/
# Source Iceland: http://www.althingi.is/english/about-the-parliament/standing-orders-of-the-althingi-/

sop.europe$sop.final[sop.europe$country == "Greece"] <- "Signal voting"
sop.europe$sop.final[sop.europe$country == "Iceland"] <- "Open voting"


# Create a dummy variable for lower and single chambers (=1, 0 otherwise)

sop.europe$lower.single <- 0

sop.europe$lower.single[sop.europe$country == "Armenia" & sop.europe$chamber == "Azgayin Zhoghov"] <- 1
sop.europe$lower.single[sop.europe$country == "Austria" & sop.europe$chamber == "Nationalrat"] <- 1
sop.europe$lower.single[sop.europe$country == "Belarus" & sop.europe$chamber == "Palata Predstavitelei"] <- 1
sop.europe$lower.single[sop.europe$country == "Belgium" & sop.europe$chamber == "Chambre des representants"] <- 1
sop.europe$lower.single[sop.europe$country == "Bosnia and Herzegovina" & sop.europe$chamber == "Predstavnicki dom"] <- 1
sop.europe$lower.single[sop.europe$country == "Bulgaria" & sop.europe$chamber == "Narodno sabranie"] <- 1
sop.europe$lower.single[sop.europe$country == "Croatia" & sop.europe$chamber == "Hrvatski Sabor"] <- 1
sop.europe$lower.single[sop.europe$country == "Cyprus" & sop.europe$chamber == "Vouli Antiprosopon"] <- 1
sop.europe$lower.single[sop.europe$country == "Czech Republic" & sop.europe$chamber == "Poslanecka Snemovna"] <- 1
sop.europe$lower.single[sop.europe$country == "Denmark" & sop.europe$chamber == "Folketinget"] <- 1
sop.europe$lower.single[sop.europe$country == "Estonia" & sop.europe$chamber == "Riigikogu"] <- 1
sop.europe$lower.single[sop.europe$country == "Finland" & sop.europe$chamber == "Eduskunta"] <- 1
sop.europe$lower.single[sop.europe$country == "France" & sop.europe$chamber == "Assemblee nationale"] <- 1
sop.europe$lower.single[sop.europe$country == "Georgia" & sop.europe$chamber == "Sakartvelos Parlamenti"] <- 1
sop.europe$lower.single[sop.europe$country == "Germany" & sop.europe$chamber == "Bundestag"] <- 1
sop.europe$lower.single[sop.europe$country == "Greece" & sop.europe$chamber == "Vouli Ton Ellinon"] <- 1
sop.europe$lower.single[sop.europe$country == "Hungary" & sop.europe$chamber == "Orszaggyules"] <- 1
sop.europe$lower.single[sop.europe$country == "Iceland" & sop.europe$chamber == "Althingi"] <- 1
sop.europe$lower.single[sop.europe$country == "Ireland" & sop.europe$chamber == "Dail Eireann"] <- 1
sop.europe$lower.single[sop.europe$country == "Isle of Man" & sop.europe$chamber == "House of Keys"] <- 1
sop.europe$lower.single[sop.europe$country == "Israel" & sop.europe$chamber == "Knesset"] <- 1
sop.europe$lower.single[sop.europe$country == "Italy" & sop.europe$chamber == "Camera dei Deputati"] <- 1
sop.europe$lower.single[sop.europe$country == "Latvia" & sop.europe$chamber == "Saeima"] <- 1
sop.europe$lower.single[sop.europe$country == "Lithuania" & sop.europe$chamber == "Seimas"] <- 1
sop.europe$lower.single[sop.europe$country == "Luxembourg" & sop.europe$chamber == "Chambre des Deputes"] <- 1
sop.europe$lower.single[sop.europe$country == "Macedonia" & sop.europe$chamber == "Sobranie"] <- 1
sop.europe$lower.single[sop.europe$country == "Moldova" & sop.europe$chamber == "Parlamentul"] <- 1
sop.europe$lower.single[sop.europe$country == "Montenegro" & sop.europe$chamber == "Skupstina"] <- 1
sop.europe$lower.single[sop.europe$country == "Netherlands" & sop.europe$chamber == "Tweede Kamer der Staten-Generaal"] <- 1
sop.europe$lower.single[sop.europe$country == "Norway" & sop.europe$chamber == "Stortinget"] <- 1
sop.europe$lower.single[sop.europe$country == "Poland" & sop.europe$chamber == "Sejm"] <- 1
sop.europe$lower.single[sop.europe$country == "Portugal" & sop.europe$chamber == "Assembleia da Republica"] <- 1
sop.europe$lower.single[sop.europe$country == "Romania" & sop.europe$chamber == "Camera Deputatilor"] <- 1
sop.europe$lower.single[sop.europe$country == "Russia" & sop.europe$chamber == "Gossoudarstvennaya Duma"] <- 1
sop.europe$lower.single[sop.europe$country == "Serbia" & sop.europe$chamber == "Narodna skupstina"] <- 1
sop.europe$lower.single[sop.europe$country == "Slovakia" & sop.europe$chamber == "Narodna rada"] <- 1
sop.europe$lower.single[sop.europe$country == "Slovenia" & sop.europe$chamber == "Drzavni Zbor"] <- 1
sop.europe$lower.single[sop.europe$country == "Spain" & sop.europe$chamber == "Congreso de los Diputados"] <- 1
sop.europe$lower.single[sop.europe$country == "Sweden" & sop.europe$chamber == "Riksdag"] <- 1
sop.europe$lower.single[sop.europe$country == "Switzerland" & sop.europe$chamber == "Nationalrat"] <- 1
sop.europe$lower.single[sop.europe$country == "Turkey" & sop.europe$chamber == "Buyuk Millet Meclisi"] <- 1
sop.europe$lower.single[sop.europe$country == "Ukraine" & sop.europe$chamber == "Verkhovna Rada"] <- 1
sop.europe$lower.single[sop.europe$country == "United Kingdom" & sop.europe$chamber == "House of Commons"] <- 1


# Read QoG time-series data set
# Source: http://qog.pol.gu.se/data/datadownloads/qogstandarddata

qog.ts <- read.table("qog_std_ts_15may13.csv", header = TRUE, sep = ";")


# Select the following variables from QoG data set:
#   ccode: country code
#   cname: country name
#   year: year
#   jw_mdist: average district magnitude (lower/only house)
#   jw_mdist2: average district magnitude (upper house)
#   jw_avgballot: party control over ballot (lower/only house)
#   jw_avgballot2: party control over ballot (upper house)
#   iaep_lcre: legislature can remove executive
#   jw_bicameral: bicameral system

qog.ts <- select(qog.ts, ccode, cname, year, jw_mdist, jw_mdist2, jw_avgballot,
                 jw_avgballot2, iaep_lcre, jw_bicameral)


# Change some country names in variable cname in qog.ts

qog.ts$cname <- as.character(qog.ts$cname)

qog.ts$cname[qog.ts$cname == "Cyprus (1975-)"] <- "Cyprus"
qog.ts$cname[qog.ts$cname == "France (1963-)"] <- "France"


# In qog.ts, select information for year 2005 and merge it with parliamentary voting data

qog.ts <- filter(qog.ts, year == 2005)

data.europe <- merge(sop.europe, qog.ts, by.x = "country", by.y = "cname", all.x = TRUE)


# For variable jw_bicameral, add information on Moldova
# Source: osce_report_elections_moldova_2005.pdf

data.europe$jw_bicameral[data.europe$country == "Moldova"] <- 0


# Add information on number of MPs in a chamber
# Source: http://www.ipu.org/parline-e/parlinesearch.asp

membs <- read.csv("numberofmps.csv")
data.europe <- merge(data.europe, membs[, 1:3], by = c("country", "chamber"), all.x = TRUE)


# For variable members, add information on Moldova
# Source: www.osce.org/odihr/elections/moldova/15251

data.europe$members[data.europe$country == "Moldova"] <- 120


# Create single variable for party control over candidate selection
# (combine jw_avgballot and jw_avgballot2)

data.europe$avgballot <- NA

data.europe$avgballot <- ifelse(data.europe$lower.single == 1, data.europe$jw_avgballot,
                                data.europe$jw_avgballot2)

# For variable avgballot, add information on Turkey

data.europe$avgballot[data.europe$country == "Turkey"] <- 0


# Create single variable for average district magnitude
# (combine jw_mdist and jw_mdist2)

data.europe$mdist <- NA

data.europe$mdist <- ifelse(data.europe$lower.single == 1, data.europe$jw_mdist,
                            data.europe$jw_mdist2)

# Create dummy variable for SMD

data.europe$mdist <- ifelse(data.europe$mdist == 1, 1, 0)


# For variable iaep_lcre, add information on Luxembourg and Iceland
# Source: http://www.ipu.org/parline-e/parlinesearch.asp

data.europe$iaep_lcre[data.europe$country == "Iceland"] <- 1
data.europe$iaep_lcre[data.europe$country == "Luxembourg"] <- 1


# Remove missings and exclude chambers that are not directly elected

data.europe <- select(data.europe, country, chamber, sop.final, lower.single, mdist,
                      avgballot, iaep_lcre, jw_bicameral, members)
data.europe <- na.omit(data.europe)
data.europe <- filter(data.europe, !(country == "Germany" & chamber == "Bundesrat"))


# Fit logistic models

data.europe$sop.final <- as.numeric(factor(data.europe$sop.final))
data.europe$sop.final <- ifelse(data.europe$sop.final == 1, 1, 0)

# Model 1

logit.1 <- glm(sop.final ~ mdist + avgballot + members + iaep_lcre + jw_bicameral,
               family = binomial(link = "logit"), data = data.europe)

summary(logit.1)
AIC(logit.1)
BIC(logit.1)
logLik(logit.1)

# Model 2

logit.2 <- glm(sop.final ~ mdist + avgballot + members + members*avgballot + iaep_lcre + jw_bicameral,
               family = binomial(link = "logit"), data = data.europe)

summary(logit.2)
AIC(logit.2)
BIC(logit.2)
logLik(logit.2)


# Based on Model 1, calculate average predictive differences

sim.coef <- sim(logit.1, n.sims = 1000)

base.p <- (sim.coef@coef[, 1]) * 0

for(i in 1:nrow(sim.coef@coef)) {
  base.p[i] <- mean(invlogit(model.matrix(logit.1) %*% (sim.coef@coef[i, ])))
}


# SMD

base.smd <- (sim.coef@coef[, 1]) * 0
data.smd <- model.matrix(logit.1)
data.smd[, 2] <- 1

for(i in 1:nrow(sim.coef@coef)) {
  base.smd[i] <- mean(invlogit(data.smd %*% (sim.coef@coef[i, ])))
}

plot(density(base.smd - base.p), xlab = "Change in probability of open voting with SMD",
     main = "Single member districts", xlim = c(-1, 1), ylim = c(0, 5))


# Party control over ballot

base.aba <- (sim.coef@coef[, 1]) * 0
data.aba <- model.matrix(logit.1)
data.aba[, 3] <- 2

for(i in 1:nrow(sim.coef@coef)) {
  base.aba[i] <- mean(invlogit(data.aba %*% (sim.coef@coef[i, ])))
}

plot(density(base.aba - base.p), xlab = "Change in probability of open voting due to absence of party control over ballot",
     main = "Average ballot under party control", xlim = c(-1, 1), ylim = c(0, 5))


# Bicameralism

base.bic <- (sim.coef@coef[, 1]) * 0
data.bic <- model.matrix(logit.1)
data.bic[, 6] <- 1

for(i in 1:nrow(sim.coef@coef)) {
  base.bic[i] <- mean(invlogit(data.bic %*% (sim.coef@coef[i, ])))
}

plot(density(base.bic - base.p), xlab = "Change in probability of open voting with bicameralism",
     main = "Bicameralism", xlim = c(-1, 1), ylim = c(0, 7))


# Size of parliament

base.mem <- (sim.coef@coef[, 1]) * 0
data.mem <- model.matrix(logit.1)
data.mem[, 4] <- max(data.mem[, 4])

for(i in 1:nrow(sim.coef@coef)) {
  base.mem[i] <- mean(invlogit(data.mem %*% (sim.coef@coef[i, ])))
}

plot(density(base.mem - base.p), xlab = "Change in probability of open voting with largest parliament (n=650)",
     main = "Size of parliament", xlim = c(-1, 1), ylim = c(0, 5))


